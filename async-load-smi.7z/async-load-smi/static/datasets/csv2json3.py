import pandas as pd
import json
from collections import OrderedDict,Counter
import math
import os
import sys
import random


def csv2graph(csv_name):   
    """
    csv文件转换为图数据并导出
    """     
    df = pd.read_csv(csv_name)
    columns_name = list(df.columns.values)

    bb_csv_indexs =[]
    bb_smi_csv_indexs = []
    for bb_n in ["BB1","BB2","BB3","BB4"]:
        bb_csv_indexs.append(columns_name.index(bb_n))
    for bb_n_smi in ["smiles1","smiles2","smiles3","smiles4"]:
        bb_smi_csv_indexs.append(columns_name.index(bb_n_smi)) 

    graph_dict = {
    "nodes": [],
    "links": []
    }
    for row_index in range(7800):

        is_chemotype = False
        for count,bb_csv_index in enumerate(bb_csv_indexs):
            if df.iloc[row_index,bb_smi_csv_indexs[count]] == "C":
                is_chemotype = True
        if is_chemotype== True:
            continue

        bb = {}
        for count,bb_csv_index in enumerate(bb_csv_indexs):

            bb[str(count+1)] = df.iloc[row_index,bb_csv_index]

            bb[str(count+1)]= "bb"+str(count+1)+"_"+str(bb[str(count+1)])+"_"+df.iloc[ row_index ,bb_smi_csv_indexs[count]]
            



            if count+1 ==1:
            
                node = {"id": bb[str(count+1)], "color": "DarkBlue"}

            if count+1 ==2:
            
                node = {"id": bb[str(count+1)], "color": "RoyalBlue"}

            if count+1 ==3:
            
                node = {"id": bb[str(count+1)], "color": "LightSteelBlue"}

            if count+1 ==4:
            
                node = {"id": bb[str(count+1)], "color": "LightSkyBlue"}



            if bb[str(count+1)].split("_")[-1] == "C":

                node = {"id": bb[str(count+1)], "color": "white"}

            elif bb[str(count+1)].split("_")[-1] == "[NA]":
                
                node = {"id": bb[str(count+1)], "color": "grey"}
            







            if node not in graph_dict["nodes"] :

                graph_dict["nodes"].append(node)




        graph_dict["links"].append({"source": bb["1"], "target": bb["2"], "value": 1})
        graph_dict["links"].append({"source": bb["2"], "target": bb["3"], "value": 1})
        graph_dict["links"].append({"source": bb["3"], "target": bb["4"], "value": 1})

    
    counter =Counter ([ str(x) for x in  graph_dict["links"]]) 

    for link in graph_dict["links"]:
        link["value"] = counter[str(link)]

    
    return graph_dict




if __name__=="__main__":
    csv_name= "data.csv"
    json_save_name = "data-7.json"



    graph_dict = csv2graph(csv_name)


    with open(json_save_name,"w") as f:
        json.dump(graph_dict,f)
        print()
        print(csv_name+" > "+json_save_name," 转换完成...")    
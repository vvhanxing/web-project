import pandas as pd
import json
from collections import OrderedDict
import math
import os
import sys
import random
def csv2graph(csv_name):   
    
    df = pd.read_csv(csv_name)

    bb1_csv_index = 16
    bb2_csv_index = 17
    bb3_csv_index = 18
    bb4_csv_index = 19
    bb_csv_indexs = [bb1_csv_index,bb2_csv_index,bb3_csv_index,bb4_csv_index]

    bb1_smi = 22
    bb2_smi = 23
    bb3_smi = 24
    bb4_smi = 25
    bb4_smi_indexs = [bb1_smi,bb2_smi,bb3_smi,bb4_smi]

    enrichment_c1_index = 4
    enrichment_c1_list = list(map(lambda x: math.log(x,10),df["enrichment(193_C1)"]))
    enrichment_c1_min = min(list(enrichment_c1_list))
    enrichment_c1_max = max(list(enrichment_c1_list))

    new_dict = {
    "nodes": [],
    "links": []
    }

    for row_index in range(7881):
        bb = {}
        for count,bb_csv_index in enumerate(bb_csv_indexs):

            bb[str(count+1)] = df.iloc[row_index,bb_csv_index]
            bb[str(count+1)]= "bb"+str(count+1)+"_"+str(bb[str(count+1)])+"_"+df.iloc[row_index,bb4_smi_indexs[count]]
            
            if bb[str(count+1)].split("_")[-1] == "C":

                node = {"id": bb[str(count+1)], "group": 3}

            elif bb[str(count+1)].split("_")[-1] == "[NA]":
                
                node = {"id": bb[str(count+1)], "group": 2}
            
            else:

                node = {"id": bb[str(count+1)], "group": 1}
            
            if node not in new_dict["nodes"]:
                new_dict["nodes"].append(node)

        new_dict["links"].append({"source": bb["1"], "target": bb["2"], "value": 1})
        new_dict["links"].append({"source": bb["2"], "target": bb["3"], "value": 1})
        new_dict["links"].append({"source": bb["3"], "target": bb["4"], "value": 1})


    with open("data.json","w") as f:
        json.dump(new_dict,f)
        print("加载入文件完成...")


if __name__=="__main__":
    csv_name= "data.csv"
    csv2graph(csv_name)